#ifdef __CINT__
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
#pragma link C++ enum emcTypes;
#pragma link C++ enum fgtTypes;
#pragma link C++ enum fmsTypes;
#pragma link C++ enum rhicfTypes;
//#ifndef __NO_STRANGE_MUDST__
//#pragma link C++ enum strangeTypes;
//#endif
#pragma link C++ enum MCTypes;
#pragma link C++ enum muDstTypes;
#pragma link C++ enum pmdTypes;
#pragma link C++ enum tofTypes;
#pragma link C++ enum btofTypes;
#pragma link C++ enum etofTypes;
#pragma link C++ enum epdTypes;
#pragma link C++ enum mtdTypes;
#pragma link C++ enum eztTypes;
#pragma link C++ enum NARRAYS;
#endif
