#include "TGraphAsymmErrorsWithReset.h"

ClassImp(TGraphAsymmErrorsWithReset);

void TGraphAsymmErrorsWithReset::Reset(){
  fNpoints=0;
}
