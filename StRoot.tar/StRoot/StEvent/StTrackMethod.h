#ifndef StTrackMethod_hh
#define StTrackMethod_hh
#include "StEnumerations.h"
// This file (StTrackMethod.h) is obsolete!
// All content from StTrackMethod.h is now in StEnumerations.h
// together with all other enumerations used in StEvent.
// Please add all enumerations to StEnumerations.h and
// change your code to NOT include StTrackMethod.h.
#endif
