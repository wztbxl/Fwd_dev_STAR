#ifndef StVertexId_hh
#define StVertexId_hh
#include "StEnumerations.h"
// This file (StVertexId.h) is obsolete!
// All content from StVertexId.h is now in StEnumerations.h
// together with all other enumerations used in StEvent.
// Please add all enumerations to StEnumerations.h and
// change your code to NOT include StVertexId.h.
#endif
