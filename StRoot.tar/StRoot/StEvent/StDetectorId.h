#ifndef StDetectorId_hh
#define StDetectorId_hh
#include "StEnumerations.h"
// This file (StDetectorId.h) is obsolete!
// All content from StDetectorId.h is now in StEnumerations.h
// together with all other enumerations used in StEvent.
// Please add all enumerations to StEnumerations.h and
// change your code to NOT include StDetectorId.h.
#endif



