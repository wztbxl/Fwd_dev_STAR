#ifndef StDedxMethod_hh
#define StDedxMethod_hh
#include "StEnumerations.h"
// This file (StDedxMethod.h) is obsolete!
// All content from StDedxMethod.h is now in StEnumerations.h
// together with all other enumerations used in StEvent.
// Please add all enumerations to StEnumerations.h and
// change your code to NOT include StDedxMethod.h.
#endif
